import Database from "better-sqlite3";

const db = new Database("./data/characters.db");

export const GetPublicCharacters = () =>
    db.prepare("SELECT * FROM characters WHERE isPublic = 1").all();

export const GetUserCharacters = (userId) =>
    db.prepare("SELECT * FROM characters WHERE userId = ?").all(userId);

export const SaveCharacter = (name, real_name, species, gender, breed, isPublic, userId, image) => db.prepare(`INSERT INTO characters(name, real_name, species, gender, breed, isPublic, userId, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(name, real_name, species, gender, breed, isPublic, userId, image);

export const UpdateCharacter = (name, real_name, species, gender, breed, isPublic, image, id, userId) => db.prepare(`UPDATE characters SET name = ?, real_name = ?, species = ?, gender = ?, breed = ?, isPublic = ?, image = ? WHERE id = ? AND userId = ?`)
    .run(name, real_name, species, gender, breed, isPublic, image, id, userId);

export const DeleteCharacter = (id, userId) =>
    db.prepare("DELETE FROM characters WHERE id = ? AND userId = ?").run(id, userId);