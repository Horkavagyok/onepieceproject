let loggedUser = null;

const authBox = document.getElementById("authSection");
const profileBox = document.getElementById("userSection");
const publicList = document.getElementById("publicCharacters");
const myList = document.getElementById("userCharacters");
const statusMessage = document.getElementById("message");

function displayMessage(messageText) {
    statusMessage.textContent = messageText;
}

// Felhasználó belépése
function enterUserArea(userData) {
    loggedUser = userData;
    authBox.hidden = true;
    profileBox.hidden = false;

    document.getElementById("welcome").textContent =
        "Szia, " + userData.username + "!";

    getMyCharacters();
}

// Kijelentkezés
function returnToGuest() {
    loggedUser = null;
    authBox.hidden = false;
    profileBox.hidden = true;
    myList.innerHTML = "";
}

// Karakterkártya létrehozása
function buildCharacterCard(characterData) {
    const card = document.createElement("div");
    card.className = "character-card";

    if (characterData.image) {
        const picture = document.createElement("img");
        picture.src = characterData.image;
        picture.alt = characterData.name;
        picture.className = "character-image";

        picture.onerror = function () {
            picture.style.display = "none";
        };

        card.appendChild(picture);
    }

    const title = document.createElement("h3");
    title.textContent = characterData.name;
    card.appendChild(title);

    const details = document.createElement("p");
    details.textContent = "Teljes név: " + characterData.real_name;
    card.appendChild(details);

    const team = document.createElement("p");
    team.textContent = "Csapat: " + characterData.breed;
    card.appendChild(team);

    return card;
}

// Publikus karakterek
function getPublicCharacters() {
    fetch("/api/characters")
        .then(response => response.json())
        .then(data => {
            publicList.innerHTML = "";

            document.getElementById("publicCount").textContent =
                data.length + " karakter";

            data.forEach(characterData => {
                publicList.appendChild(buildCharacterCard(characterData));
            });
        });
}

// Saját karakterek
function getMyCharacters() {
    if (!loggedUser) return;

    fetch("/api/users/characters/" + loggedUser.id)
        .then(response => response.json())
        .then(data => {
            myList.innerHTML = "";

            data.forEach(characterData => {
                const item = document.createElement("div");
                item.className = "own-card";

                const characterName = document.createElement("strong");
                characterName.textContent = characterData.name;
                item.appendChild(characterName);

                const visibility = document.createElement("p");
                visibility.textContent = characterData.isPublic
                    ? "Publikus"
                    : "Privát";
                item.appendChild(visibility);

                const editButton = document.createElement("button");
                editButton.textContent = "Módosítás";
                editButton.onclick = function () {
                    fillCharacterForm(characterData);
                };
                item.appendChild(editButton);

                const deleteButton = document.createElement("button");
                deleteButton.textContent = "Törlés";
                deleteButton.onclick = function () {
                    removeCharacter(characterData.id);
                };
                item.appendChild(deleteButton);

                myList.appendChild(item);
            });
        });
}

// Karakter adatai módosításhoz
function fillCharacterForm(characterData) {
    document.getElementById("editId").value = characterData.id;
    document.getElementById("characterName").value = characterData.name;
    document.getElementById("realName").value = characterData.real_name;
    document.getElementById("species").value = characterData.species;
    document.getElementById("gender").value = characterData.gender;
    document.getElementById("breed").value = characterData.breed;
    document.getElementById("image").value = characterData.image || "";
    document.getElementById("isPublic").value = characterData.isPublic;

    document.getElementById("formTitle").textContent =
        "Karakter módosítása";

    document.getElementById("saveButton").textContent =
        "Módosítás mentése";

    document.getElementById("cancelEdit").hidden = false;
}

// Űrlap kiürítése
function resetCharacterForm() {
    document.getElementById("characterForm").reset();
    document.getElementById("editId").value = "";
    document.getElementById("realName").disabled = false;

    document.getElementById("formTitle").textContent =
        "Új karakter hozzáadása";

    document.getElementById("saveButton").textContent =
        "Karakter mentése";

    document.getElementById("cancelEdit").hidden = true;
}

// Regisztráció
document.getElementById("registerForm").onsubmit = function (event) {
    event.preventDefault();

    fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: document.getElementById("regUsername").value,
            email: document.getElementById("regEmail").value,
            password: document.getElementById("regPassword").value
        })
    })
        .then(response => response.json())
        .then(data => {
            displayMessage(data.message);
            document.getElementById("registerForm").reset();
        });
};

// Bejelentkezés
document.getElementById("loginForm").onsubmit = function (event) {
    event.preventDefault();

    fetch("/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: document.getElementById("loginEmail").value,
            password: document.getElementById("loginPassword").value
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.id) {
                enterUserArea(data);
                displayMessage("Sikeres bejelentkezés!");
                document.getElementById("loginForm").reset();
            } else {
                displayMessage(data.message);
            }
        });
};

// Új karakter
document.getElementById("characterForm").onsubmit = function (event) {
    event.preventDefault();

    const characterId = document.getElementById("editId").value;

    const characterData = {
        name: document.getElementById("characterName").value,
        real_name: document.getElementById("realName").value,
        species: document.getElementById("species").value,
        gender: document.getElementById("gender").value,
        breed: document.getElementById("breed").value,
        image: document.getElementById("image").value,
        isPublic: Number(document.getElementById("isPublic").value),
        userId: loggedUser.id
    };

    let requestUrl = "/api/users/characters";
    let requestMethod = "POST";

    if (characterId) {
        requestUrl += "/" + loggedUser.id + "/" + characterId;
        requestMethod = "PUT";
    }

    fetch(requestUrl, {
        method: requestMethod,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(characterData)
    })
        .then(response => response.json())
        .then(data => {
            displayMessage(data.message);
            resetCharacterForm();
            getMyCharacters();
            getPublicCharacters();
        });
};

// Karakter törlése
function removeCharacter(characterId) {
    if (confirm("Biztosan törlöd ezt a karaktert?")) {
        fetch("/api/users/characters/" + loggedUser.id + "/" + characterId, {
            method: "DELETE"
        })
            .then(response => response.json())
            .then(data => {
                displayMessage(data.message);
                getMyCharacters();
                getPublicCharacters();
            });
    }
}

// Kijelentkezés
document.getElementById("logoutButton").onclick = function () {
    returnToGuest();
    resetCharacterForm();
    displayMessage("Sikeresen kijelentkeztél!");
};

// Mégse
document.getElementById("cancelEdit").onclick = resetCharacterForm;

//Oldal megnyitásakor betöltenek a karakterek
getPublicCharacters();
