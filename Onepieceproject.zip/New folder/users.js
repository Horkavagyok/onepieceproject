import bcrypt from "bcrypt";
import express from "express";
import * as db from "./data/UsersDB.js";
import * as characterdb from "./data/CharacterDB.js";

const router = express.Router();

// Regisztráció
router.post("/", (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: "Hiányzó adatok!" });
    }

    const salt = bcrypt.genSaltSync();
    const hashedPassword = bcrypt.hashSync(password, salt);

    try {
        db.SaveUser(username, email, hashedPassword);
        res.status(201).json({ message: "Sikeres regisztráció!" });
    } catch (error) {
        res.status(400).json({ message: "Ez az e-mail cím vagy felhasználónév már foglalt!" });
    }
});

// Bejelentkezés
router.post("/login", (req, res) => {
    const { email, password } = req.body;

    const user = db.GetUserByEmail(email);

    if (!user || !bcrypt.compareSync(password, db.GetPwById(user.id))) {
        return res.status(400).json({ message: "Hibás adatok!" });
    }

    res.status(200).json(user);
});

// Saját karakterek
router.get("/characters/:userId", (req, res) => {
    const userId = Number(req.params.userId);

    const characters = characterdb.GetUserCharacters(userId);;

    res.status(200).json(characters);
});

// Új karakter
router.post("/characters", (req, res) => {
const { name, real_name, species, gender, breed, isPublic, userId, image } = req.body;

    if (!name || !real_name || !species || !gender || !breed || isPublic === undefined || userId === undefined) {
        return res.status(400).json({ message: "Hiányzó adatok!" });
    }

    try {
        const saved = characterdb.SaveCharacter(
    name, real_name, species, gender, breed,
    Number(isPublic), Number(userId), image || "");

        res.status(201).json({ message: "Karakter sikeresen hozzáadva!" });
    } catch (error) {
        res.status(400).json({ message: "Már létezik ilyen karakter!" });
    }
});

// Karakter módosítása
router.put("/characters/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);

const { name, real_name, species, gender, breed, isPublic, image } = req.body;

    const updated = characterdb.UpdateCharacter(
    name, real_name, species, gender, breed,
    Number(isPublic), image || "", id, userId
    );

    if (updated.changes === 0) {
        return res.status(404).json({ message: "A karakter nem található!" });
    }

    res.status(200).json({ message: "Karakter módosítva!" });
});

// Karakter törlése
router.delete("/characters/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);

    const deleted = characterdb.DeleteCharacter(id, userId);

    if (deleted.changes === 0) {
        return res.status(404).json({ message: "A karakter nem található!" });
    }

    res.status(200).json({ message: "Karakter törölve!" });
});

export default router;