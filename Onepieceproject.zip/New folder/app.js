import express from "express";
import characters from "./characters.js";
import users from "./users.js";

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("index"));

app.use("/api/characters", characters);
app.use("/api/users", users);

app.listen(PORT, () => {
    console.log(`Server runs on port: ${PORT}`);
});