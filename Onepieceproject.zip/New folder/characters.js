import express from "express";
import * as db from "./data/CharacterDB.js";

const router = express.Router();
router.get("/", (req, res) => {
    const characters = db.GetPublicCharacters();
    res.json(characters);
});

export default router;
